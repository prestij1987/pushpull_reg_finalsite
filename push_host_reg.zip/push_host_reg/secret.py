# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'django-insecure-jsuxmpu&kme*a=sa4f--d6m#5jrc9d1slg=1y!%!46es$x6#ej'

token = '7392165002:AAHyA0Ua5wKL_MjqQk2e99EpZU7av8DDT7E'