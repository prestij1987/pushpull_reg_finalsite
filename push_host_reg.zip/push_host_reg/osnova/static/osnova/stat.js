console.log('kuku');

window.addEventListener(
    'load',
    
  first_js_func
    
)
function first_js_func(){
    console.log(my_name.value)
}